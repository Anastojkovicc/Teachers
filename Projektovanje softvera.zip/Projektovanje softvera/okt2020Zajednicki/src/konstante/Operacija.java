/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package konstante;

import java.io.Serializable;

/**
 *
 * @author ANA
 */
public class Operacija implements Serializable{
    public static final int SACUVAJ_ANGAZOVANJA=1;
    public static final int VRATI_KORISNIKA=2;
    public static final int VRATI_NASTAVNIKE=3;
    public static final int VRATI_PREDMETE=4;
}
